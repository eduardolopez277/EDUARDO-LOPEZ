peliculas = {
    "P101": ["luz de otoño","drama",110,"b","español",False],
    "P102": ["noche ne neon","accion",125,"c","ingles",True],
    "P103": ["planeta agua","documental", 90,"a","español",False],
    "P104": ["risa total","comedia", 105,"a","español",True],
    "P103": ["codigo zero","thriller", 118,"c","ingles",True],
    "P103": ["viaje lunar","ciencia ficcion", 132,"b","ingles",False],
}

cartelera= {
    "P101": [5990, 40],
    "P102": [7990, 0],
    "P103": [4990, 25],
    "P104": [6990, 12],
    "P105": [8990, 8],
    "P106": [7990, 3],
}
def cupos_generos(generos):
    total = 0
    gen_b = genero.lower()
    for cod in peliculas:
        lista_peli = peliculas[cod]
        gen_peli = lista_peli[1].lower()
        if gen_peli == gen_b:
             if cod in cartelera:
                 total = total + cartelera[cod][1]
    print("el total de cupos disponibles es:", total)
        
       
    
def busqueda_precio(p_min, p_max):
    resultado = []
    gen_b = genero.lower()
    for cod in cartelera:
        cupos = cartelera[cod][1]
        if precio >= p_min and precio <= p_max and cupos >0:
            if cod in peliculas:
                 titulo = peliculas [cod][0]
                 texto = titulo + "--" + cod
                 resultados.append(texto)
                 
    if len (resultados)==0:
        print("no hay peliculas en ese rango de precio")
    else:
        resultados.sort()
        print("las peliculas encontradas son:", resultados)

def actualizar_precio(codigo, nuevo_precio):
    cod_u = codigo.upper()
    if cod_u in cartelera:
        cartelera[cod_u][0]= nuevo_precio
        return True
    else:
        return False
def val_cod(texto):
    if texto.strip()== "":
        return True
    else:
        return False
    
def val_tit(texto):
    if texto.strip()== "":
        return True
    else:
        return False
    
def val_dur(texto):
    if texto.isdigitid()== True:
        if int(texto) > 0:
            return True
    return False

def val_cla(texto):
    if texto == 'A' or texto == 'B' or texto == 'C':
        return True
    else:
        return False
    
def val_idi(texto):
    if texto.strip() == "":
        return True
    else:
        return False

def val_idi(texto):
    if texto == 's' or texto == 'n':
        return True
    else:
        return False    
    
def val_3d(texto):
    if texto == 's' or texto == 'n':
        return True
    else:
        return False   

def val_pre(texto):
    if texto.isdigit() == True:
        if int(texto) > 0:
            return True
        return False   

def val_cup(texto):
    if texto.isdigit() == True:
        if int(texto) >= 0:
            return True
        return False   
    
def agregar_pelicula(codigo, titulo, genero, duracion, clasificacion, idioma, es_3d, precio, cupos):
    cod_u = codigo.upper()
    if cod_u in peliculas or cod_u in cartelera:
        return False
    if es_3d == 's':
        es_3d_bool = True
        
    peliculas[cod_u] = [titulo, genero, int(duracion),clasificacion,idioma,es_3d_bool]
    cartelera[cod_u] = [int(duracion),int(cupos)]
    return True

def eliminar_peliculas(codigo):
    cod_u = codigo.upper()
    if cod_u in peliculas and cod_u in cartelera:
        peliculas.pop(cod_u)
        cartelera.pop(cod_u)
        return True
    else:
        return False
    
while True:
    print("\n===========MENU PRINCIPAL=============")
    print("1.cupos por generos")
    print("2.busqueda de peliculas por rango de genero")
    print("3.actualizar precios de pelicula")
    print("4.agregar pelicula")
    print("5.eliminar pelicula")
    print("6.salir")
    print("============================================")
    
    opc = input("ingrese una opcion: ")
    
    if opc =="1":
        gen_in = input("ingrese genero a consultar: ")
        cupos_generos(gen_in)
        
    elif opc == "2":
        while True:
            try:
                p_min_txt = input("Ingrese precio mínimo: ")
                p_min = int(p_min_txt)
                p_max_txt = input("Ingrese precio máximo: ")
                p_max = int(p_max_txt)
                
                if p_min >= 0 and p_max >= 0 and p_min <= p_max:
                    busqueda_precio(p_min, p_max)
                    break
                else:
                    print("valores incorrectos. reintente")
            except ValueError:
                print("debe ingresar valores enteros")
                
    elif opc == "3":
        while True:
            cod_peli = input("Ingrese código de película: ")
            nuevo_p_txt = input("Ingrese nuevo precio: ")
            
            if nuevo_p_txt.isdigit() == True and int(nuevo_p_txt) > 0:
                nuevo_p = int(nuevo_p_txt)
                if actualizar_precio(cod_peli, nuevo_p) == True:
                    print("Precio actualizado")
                else:
                    print("El código no existe")
            else:
                print("Error: El nuevo precio debe ser un número entero positivo.")
                
            resp = input("¿Desea actualizar otro precio (s/n)?: ")
            if resp.lower() == "n":
                break
    elif opc == "4":
        c = input("Ingrese código de película: ")
        if val_cod(c) == False or c.upper() in peliculas:
            print("Error en código (ya existe o está vacío).")
            continue
        t = input("Ingrese título: ")
        if val_tit(t) == False:
            print("Error en título.")
            continue
        g = input("Ingrese genero: ")
        if val_gen(g) == False:
            print("Error en genero.")
            continue
        d = input("Ingrese duracion(minutos): ")
        if val_dur(d) == False:
            print("Error en duracion.")
            continue
        cl = input("Ingrese clasificacion: ")
        if val_cla(cl) == False:
            print("Error en clasificacion.")
            continue
        i = input("Ingrese idioma: ")
        if val_idi(i) == False:
            print("Error en idioma.")
            continue
        
        td = input("¿es 3d? (si/no): ")
        if val_3d(td) == False:
            print("error en el 3d.")
            continue
        pr = input("Ingrese precio: ")
        if val_pre(pr) == False:
            print("Error en precio.")
            continue
        cu = input("Ingrese cupos: ")
        if val_cup(cu) == False:
            print("Error en cupos.")
            continue
        if agregar_pelicula(c,t,g,d,cl,i,td,pr,cu)== True:
            print("pelicula agregada")
        else:
            print("el codigo ya existe")
            
    elif opc == 5:
        cod_eliminar = input("Ingrese código de película a eliminar: ")
        if eliminar_pelicula(cod_eliminar) == True:
            print("Película eliminada")
        else:
            print("El código no existe")
    elif opc == 6:
        print("programa finalizado")
        break
    else:
        print("debe ingresar una opcion valida")