def mostrar_menu():
    print("===========MENU PRINCIPAL=============")
    print("1. agregar productos")
    print("2. buscar producto")
    print("3. eliminar producto")
    print("4. actualizar disponibilidad")
    print("5. mostrar producto")
    print("6. salir")
    print("7.=====================================")

def leer_opcion():
    while True:
        opc = input("seleccione una opcion: ")
        if opc == "1" or opc =="2" or opc == "3" or opc == "4" or opc == "5" or opc == "6":
            return int(opc)
        print("opcion invalida. intente nuevamente.")

def validar_nombre(texto):
    if texto.strip() == "":
        return False
    else:
        return True
    
def validar_stock(texto):
    if texto.isdigit():
        num = int(texto)
        if num >=0:
            return True
    return False

def validar_precio(texto):
    try:
        num = float(texto)
        if num > 0:
            return True
        else:
            return False
    except ValueError:
        return False
    
def agregar_producto(lista_prod):
    nom = input("ingrese el nombre del producto: ")
    if validar_nombre(nom) == False:
        print("error.el nombre no puede ser vacio ni ser solo espacio.")
        return
    
    stk_txt= input("ingrese el stock en bodega: ")
    if validar_stock(stk_txt) == False:
        print("error.el numero tiene que ser un numero entero mayor o igual a cero.")
        return
    
    prc_txt = input("ingrese el precio del producto: ")
    if validar_precio(prc_txt) == False:
        print("error.el numero debe ser un numero decimal o mayor a cero.")
        return
    
    producto = {}
    producto["nombre"] = nom
    producto["stock"] = int(stk_txt)
    producto["precio"] = float(prc_txt)
    producto["disponible"] = False

    lista_prod.append(producto)
    print("producto agregado exitosamente")

def buscar_producto(lista_prod, nom_buscar):
    for i in range(len(lista_prod)):
        prod_actual = lista_prod[i]
        if prod_actual["nombre"] == nom_buscar:
            return i
    return -1

def actualizar_disponibilidad(lista_prod):
    for i in range(len(lista_prod)):
        if lista_prod[i]["stock"] > 0:
            lista_prod[i]["disponible"] = True
        else:
            lista_prod[i]["disponible"] = False

productos = []

while True:
    mostrar_menu()
    opcion = leer_opcion()

    if opcion == 1:
        agregar_producto(productos)
    
    elif opcion == 2:
        busqueda = input("ingrese el nombre del producto: ")
        pos = buscar_producto(productos, busqueda)
        if pos != -1:
            p = productos[pos]
            print("")
            print("producto encontrado en la posicion", pos)
            print("nombre:", p["nombre"])
            print("stock:", p["stock"])
            print("precio:", p ["precio"])
            if p["disponible"] == True:
                print("estado: disponible")
            else:
                print("estado: sin stock")
        else:
            print("producto no encontrado")

    elif opcion == 3:
        eliminar = input("ingrese el producto a eliminar: ")
        pos = buscar_producto(productos, eliminar)
        if pos != -1:
            productos.pop(pos)
            print("producto eliminado exitosamente")
        else:
            print("el producto '" + eliminar + "' no se encuentra registrado.")

    elif opcion == 4:
        actualizar_disponibilidad(productos)
        print("disponibilidad actualizada globalmente")
    elif opcion == 5:
        actualizar_disponibilidad(productos)
        print("")
        print("==========LISTA DE PRODUCTOS===========")
        for i in range(len(productos)):
            p = productos[i]
            print("nombre:", p ["nombre"])
            print("stock:", p ["stock"])
            print("precio:", p ["prcio"])
            if p ["disponible"] == True:
                print("estado: disponible")
            else:
                print("estado: sin stock")
            print("*******************************")
    
    elif opcion == 6:
        print("gracias por usar el sistema. vuelva pronto")
        break
